import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  UseGuards,
  Req,
} from '@nestjs/common';
import { AtividadeService } from './atividade.service';
import { AtividadeDTO } from './dto/atividade.dto';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@Controller('atividade')
export class AtividadeController {
  constructor(private readonly atividadeService: AtividadeService) { }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(1, 4)
  @Post()
  create(@Body() data: AtividadeDTO, @Req() req: any) {
    const userId = req.user.id_usuario;
    const userRole = req.user.tipo;
    return this.atividadeService.create(data, userId, userRole);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(1, 4)
  @Post('batch')
  createBatch(@Body() data: { atividades: AtividadeDTO[] }, @Req() req: any) {
    const userId = req.user.id_usuario;
    const userRole = req.user.tipo;
    return this.atividadeService.createBatch(data.atividades, userId, userRole);
  }

  @Get()
  findAll() {
    return this.atividadeService.findAll();
  }

  @Get("/full/:id_evento")
  findAllFullInfosById(@Param('id_evento') id_evento: string) {
    return this.atividadeService.findAllFullInfosById(Number(id_evento));
  }

  @Get("/full")
  findAllFullInfos() {
    console.log("entrei na rota full")
    return this.atividadeService.findAllFullInfos();
  }



  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(1, 3)
  @Post(':id/inscrever-participantes')
  inscreverParticipantes(
    @Param('id') id: string,
    @Body() data: { emails: string[] },
  ) {
    return this.atividadeService.inscreverParticipantesPorEmail(Number(id), data.emails);
  }

  @Get(':id/participantes')
  findByIdWithParticipants(@Param('id') id: string) {
    return this.atividadeService.findByIdWithParticipants(Number(id));
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    console.log("entrei na rota id")
    if (id.includes('full'))
      return this.atividadeService.findAllFullInfos();
    return this.atividadeService.findById(Number(id));
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(1, 4)
  @Put(':id')
  update(@Param('id') id: string, @Body() data: AtividadeDTO, @Req() req: any) {
    const userId = req.user.id_usuario;
    const userRole = req.user.tipo;
    return this.atividadeService.update(Number(id), data, userId, userRole);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(1, 4)
  @Delete(':id')
  delete(@Param('id') id: string, @Req() req: any) {
    const userId = req.user.id_usuario;
    const userRole = req.user.tipo;
    return this.atividadeService.delete(Number(id), userId, userRole);
  }
}
